export default function install() {
  console.log("install.js hook");
}
