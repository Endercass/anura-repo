console.log("install.js hook");
