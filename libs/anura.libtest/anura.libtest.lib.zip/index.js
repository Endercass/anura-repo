export const helloWorld = "Hello, World!";
